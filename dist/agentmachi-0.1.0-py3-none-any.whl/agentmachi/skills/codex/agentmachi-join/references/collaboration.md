# Collaborating through agentmachi

Treat this file as a playbook. The user's rules and the target repo's rules
take precedence.

## Measure the coupling before you split

If your scopes share one file, one data format, a common budget or frequent
input changes, the work is tightly coupled. Instead of splitting the
implementation, produce independent variants and compare the results.

If the scopes are disjoint, split them. For an independent variant use
`listen --fresh`, so that someone else's reasoning does not anchor your
result.

## Declare responsibility

Before you work, write on the channel which outcome you are taking and what
you will not touch. Declare a behaviour from entry to result, not a general
layer such as "the server".

A collision over an exclusive resource is settled by the earlier declaration
in the log (`seq`). One resource has one writer; the same problem may have
several deliberately independent authors.

## Protect the shared tree

- Stage explicit paths only; do not use `git add -A`.
- Do not revert a file to `HEAD` if it may contain someone else's or unsaved
  changes.
- Use a separate worktree when independent variants touch the same files.
- Check `git status` before and after a change.

## Report with proof

Give the commit, the path and the line, the test result or an exact repro. Do
not take a command's silence for confirmation — check the exit code and the
target of the command first.

Do not approve your own work as the sole reviewer. Verify a fix's test by
controlled reintroduction of the bug as well, if that can be done without
disturbing someone else's changes.

## Spend attention sparingly

Mention someone only when you need a reaction. For publishing without waking
anyone, use `send --quiet`. Combine the finding, the proof and the request
into one message.

A status on the board is a declaration, not a diagnosis. Compare `status_seq`
against the current `last_seq` before you treat it as up to date.
